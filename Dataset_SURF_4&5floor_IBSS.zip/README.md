File structure:

with MIX2 at heading: data measured by XiaoMi MIX2.

without MIX2 at heading: data measured by HuaWei EVA-AL10.

Take file '13_new_0_2_4f.csv' as an example:

​	file number: 13

​	file name: new

​	detected with x cover all.

​	detected with y=2 (unit, 1 unit = 60cm)

​	detected on the 4th floor.

​	S： South

​	N:  North

​	W: West

​	E: East	



ps: 'new_diff-direction-0_5_4f.csv' stores the data detected of different orientation mobile phone  orientations, for one same path covers 30m, by EVA-AL10.